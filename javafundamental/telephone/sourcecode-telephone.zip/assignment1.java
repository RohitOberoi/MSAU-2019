package practice;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Scanner;

import javafx.util.Pair;

interface Telephone{
	public void dail();
	public void receive();
	public void history();
	public void save_contact();
}
class OtherUser{
	String name;
	String number;
	String address;
}
class Duration{
	Date start;
	Date end;
}
public class assignment1 extends MyPhone {
	public static void main(String arg[]) throws InterruptedException
	{
		int a=4;
		MyPhone f= new MyPhone();
		int q;
		do
		{
			System.out.println("Enter 1 to dial");
			System.out.println("Enter 2 to receive");
			System.out.println("Enter 3 to get history");
			System.out.println("Enter 4 to save contact");
			System.out.println("Enter 5 to exit");
			Scanner sc1=new Scanner(System.in);
			q=sc1.nextInt();
			switch(q) {
			case 1:
				f.dail();
				break;
			case 2:
				f.receive();
				break;
			case 3:
				f.history();
				break;
			case 4:
				f.save_contact();
				break;
			case 5:
				break;
			default:
				System.out.println("enter a valid number");
			}
			Thread.sleep(1000);
		}
		while(q!=5);
		
	}
	
	
}
class MyPhone extends OtherUser implements Telephone {
	Map<String,List<Duration>>dailed= new HashMap<String,List<Duration>>();
	Map<String,List<Duration>>received= new HashMap<String,List<Duration>>();
	Map<String,Pair<String , String>>iuser=new HashMap<>();
	static int d1=0,r1=0;
	public void dail() 
	{
		System.out.println("press 0 for contacts and 1 for typing number");
		Scanner s= new Scanner(System.in);
		int c=s.nextInt();
		String  n;
		if(c==0)
		{
			if(iuser.isEmpty())
			{
				System.out.println("No number saved");
				return ;
			}
			for(Map.Entry<String,Pair<String,String>> e: iuser.entrySet())
			{
				System.out.println(e.getKey());
			}
			System.out.println("choose contact by entering name");
			Scanner sc=new Scanner(System.in);
			String name=sc.nextLine();
			System.out.println("Calling .... ");
			Pair<String,String>p=iuser.get(name);
			n=p.getKey();
		}
		else
		{
			System.out.println("Enter number u wanna call");
			Scanner sc=new Scanner(System.in);
			n=sc.nextLine();
			if(n.length()==10)
			System.out.println("Calling .... ");
			else
			{
				System.out.println("Please check the number you have dailed");
				return;
			}
		}
		Duration d= new Duration();
		d.start=new Date();
		int n1;
		do {
			System.out.print("Press 0 to end");
			Scanner s1=new Scanner(System.in);
			n1=s.nextInt();
			if(n1==0)
			{
				d.end=new Date();
			}
		}
			while(n1!=0);
			
		if(dailed.containsKey(n))
		{
			 dailed.get(n).add(d);
		}
		else
		{
			List<Duration> l= new ArrayList<>();
			l.add(d);
			dailed.put(n,l);
		}
		
	}
	public void receive()
	{
		int aNumber = 0; 
		aNumber = (int)((Math.random() * 900000000)+900000000); 
		String s=Integer.toString(aNumber);
		System.out.println("receiveing call from"+s);
		Duration d= new Duration();
		d.start=new Date();
		int n1;
		do {
			System.out.print("Press 0 to end");
			Scanner s1=new Scanner(System.in);
			n1=s1.nextInt();
			if(n1==0)
			{
				d.end=new Date();
			}
		}
			while(n1!=0);
			
		if(received.containsKey(s))
		{
			 received.get(s).add(d);
		}
		else
		{
			List<Duration> l= new ArrayList<>();
			l.add(d);
			received.put(s,l);
		}
	
		
	}
	public void history()
	{
		for(Map.Entry<String,List<Duration>> entry : dailed.entrySet())
			{
				System.out.println("you dailed : "+ entry.getKey()+ " which started at : ");
				ListIterator ltr = entry.getValue().listIterator();
				 while (ltr.hasNext()) 
			     { 
					 Duration d= (Duration)ltr.next();
				 	System.out.println(d.start+"and ended at"+d.end);
		   		}
			}
		for(Map.Entry<String,List<Duration>> entry : received.entrySet())
		{
			System.out.println("you dailed : "+ entry.getKey()+ " which started at : ");
			ListIterator ltr = entry.getValue().listIterator();
			 while (ltr.hasNext()) 
		     { 
				 Duration d= (Duration)ltr.next();
			 	System.out.println(d.start+"and ended at"+d.end);
	   		}
		}
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public void save_contact() {
		String n;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter number u wanna save");
		n=s.nextLine();
		System.out.println("Enter name");
		String name=s.nextLine();
		System.out.println("Enter Address");
		String add=s.nextLine();
		Pair p=new Pair(n,add);
		iuser.put(name,p);
	}
}