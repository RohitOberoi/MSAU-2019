package practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

class MyCompare1 implements Comparator<Elements>{

		@Override
	public int compare(Elements arg0, Elements arg1) {
		// TODO Auto-generated method stub
			if(arg0.to>arg1.to)
				return -1;
			else if(arg0.to>arg1.to)
				return 1;
			else
				return 0;
	}
	
}

class Elements{
	int i;								// people ID
	int to;								// floor they want to go
}
public class assignment1_2 {
	public static void main(String arg[])
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter number of floors");
		int floor=sc.nextInt();
		System.out.print("Enter number of people");
		int people=sc.nextInt();
		System.out.print("Enter present floor");
		int pf=sc.nextInt();
		System.out.print("Enter preferred floors want to go");
		ArrayList<Elements>arr=new ArrayList<Elements>();
		for(int j=1;j<=people;j++)
		{
			Elements e=new Elements();
			e.i=j;
			Scanner sc1=new Scanner(System.in);
			e.to=sc1.nextInt();
			arr.add(e);
		}
		Collections.sort(arr,new MyCompare1());
		for(int i=0;i<arr.size();i++)
			System.out.println(arr.get(i).i+" "+arr.get(i).to);
		
		int k=1;
		if(people%2!=0)
		{
			
			int p=arr.get(people/2).to;
			if(p>pf)
			{
				k=0;
				System.out.println("PEOPLE IN LIFT-A are : " );
				for(int j=people/2;j>=0;j--)
					System.out.println(arr.get(j).i);
				System.out.println("PEOPLE IN LIFT-B are : " );
				for(int j=people-1;j>people/2;j--)
					System.out.println(arr.get(j).i);
			}
				
		}
		if(k==1)
		{
			System.out.println("PEOPLE IN LIFT-A are : " );
			for(int j=people/2-1;j>=0;j--)
				System.out.println(arr.get(j).i);
			System.out.println("PEOPLE IN LIFT-B are : " );
			for(int j=people-1;j>=people/2;j--)
				System.out.println(arr.get(j).i);
			}
		
	}	
}
